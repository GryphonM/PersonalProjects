//------------------------------------------------------------------------------
//
// File Name:	BetaLowWindows.h
// Author(s):	Jeremy Kings (j.kings)
// Project:		BetaFramework
// Course:		WANIC VGP2 2018-2019
//
// Copyright � 2019 DigiPen (USA) Corporation.
//
//------------------------------------------------------------------------------

#pragma once

// User input
#include <Input.h>

// Window settings
#include <WindowSystem.h>

//------------------------------------------------------------------------------
